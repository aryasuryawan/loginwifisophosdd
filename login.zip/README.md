﻿# loginwifidd
Halaman Login ini dibuat sebagai HTML Template Login Portal Internet Sophos. Nantinya akan diganti dengan slug di Firewall Sophos berikut

<p><div id=&quot;__loginbox&quot;></div> </div>
<div id=&quot;request-url&quot; style=&quot;display:none;&quot;>{url}</div> 
<script> var redirect_url = document.getElementById(&quot;request-url&quot;).innerHTML; </script></p>


Bila tambah news feed dari website
![image](https://github.com/aryasuryawan/loginwifisophosdd/assets/28218735/ec3ca7b4-58f8-41f3-a16a-850eb753c47f)


Bootsrap 3
Jquery
HTML
